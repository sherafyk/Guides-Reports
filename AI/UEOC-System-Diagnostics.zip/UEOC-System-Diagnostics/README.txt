README.txt — UEOC System Diagnostics (Windows)
Version: 3.0.0
Developer: Sherafgan Khan
Sponsor: Fabled Sky Research
Last updated: 2025-12-19




================================================================================
WHAT THIS IS
================================================================================
This folder contains a simple “click-to-run” diagnostics tool for Windows.

When you double-click it, it collects basic information about your computer
(Windows version, Python, GPU, etc.) and writes it into ONE text file.

That text file is meant to be copy/pasted into a support chat (or sent to a
developer / AI assistant) so they can help you faster without asking you
20+ questions.

IMPORTANT: The log is overwritten each time you run it.
You will NOT get a pile of 50 log files.




================================================================================
WHAT’S IN THIS FOLDER
================================================================================
You should see (at minimum):

1) Run-Diagnostics.bat
   - This is the “launcher” you double-click.

2) Collect-System-Diagnostics.ps1
   - This is the script that collects the info and writes the log.

Optional (auto-created after a run):
3) Open System Diagnostic Log.lnk
   - A shortcut that opens the log (text file) file instantly.

KEEP THESE FILES TOGETHER IN THE SAME FOLDER.
Do not rename them unless you also update the script.




================================================================================
WHAT HAPPENS WHEN YOU RUN IT
================================================================================
1) You double-click: Run-Diagnostics.bat
2) A black command window may appear for a moment.
   - This is normal.
3) It creates/overwrites a log file called:
   System-Diagnostic-Log-UEOC.txt
4) Notepad opens automatically with that log file.

That’s it.




================================================================================
WHERE THE LOG FILE IS SAVED
================================================================================
The log is saved to a “safe, always-writable” Windows temp folder:

  C:\Users\<YOUR_USERNAME>\AppData\Local\Temp\UEOC_Diagnostics\
    System-Diagnostic-Log-UEOC.txt

This is normal on Windows. It avoids permission problems.

You DO NOT need to browse there manually:
- The script opens the file for you in Notepad
- And it creates/updates a shortcut in the tool folder:
  “Open System Diagnostic Log.lnk”




================================================================================
WHAT INFORMATION IT COLLECTS
================================================================================
The log includes (typical examples):
- Your Windows version and PowerShell version
- Key environment variables (like PATH)
- Where Python is installed and which Python runs when you type “python”
- Python + pip linkage (so we know you aren’t installing packages into the wrong place)
- Conda info (if installed)
- Tool checks:
  - git --version
  - node --version / npm --version (if installed)
  - docker --version / docker info (if installed)
  - nvidia-smi (GPU + CUDA driver info, if NVIDIA is present)
  - netsh winhttp show proxy (proxy settings)
- “where …” checks (shows if multiple copies of tools exist and which one wins)

If a tool is not installed, that section will say something like:
- “Not found on PATH.” or
- “is not recognized as an internal or external command”
That is NOT a crash. It’s valuable information.




================================================================================
PRIVACY / SAFETY NOTES (PLEASE READ)
================================================================================
This log can contain personal/system-identifying info, such as:
- Your Windows username
- Your computer name
- Local install paths (which may include your username)
- Lists of installed tool locations

It does NOT intentionally collect:
- Passwords
- Browser history
- Personal documents
- Your files’ contents

Before posting publicly (forums, screenshots, etc.), you may want to redact:
- Your username (C:\Users\YOURNAME\...)
- Your computer name (COMPUTERNAME)
- Any sensitive path names

If you’re sending it privately to a developer/assistant, usually no redaction is needed.




================================================================================
HOW TO USE THIS LOG FOR SUPPORT (IMPORTANT)
================================================================================
This diagnostics log exists to save time and prevent confusion.

It is designed to be used together with the UEOC (Universal Engineering Operating
Contract), which defines how technical help (especially from AI) should be given
in a clear, disciplined, and reproducible way.

The UEOC lives here:
https://fs7.org/ueoc

You do NOT need to paste the full contract. The link points to the authoritative,
raw GitHub markdown version, which the AI can read directly.




--------------------------------------------------------------------------------
STEP-BY-STEP: HOW TO ASK FOR HELP (THE RIGHT WAY)
--------------------------------------------------------------------------------

1) Run the diagnostics  
   - Double-click: Run-Diagnostics.bat  
   - Notepad will open with the system log.

2) Copy the full log  
   - Press Ctrl+A (Select All)  
   - Press Ctrl+C (Copy)

3) Paste the following UEOC Diagnostics Prompt into your AI or support chat,
   then paste your full system log where indicated, and finally write your
   actual question.




--------------------------------------------------------------------------------
UEOC DIAGNOSTICS PROMPT (COPY / PASTE)
--------------------------------------------------------------------------------

IMPORTANT CONTEXT FOR THIS REQUEST:

Before responding, you MUST read and follow the Universal Engineering Operating
Contract (UEOC) at the following link:

https://fs7.org/ueoc

That link points to the authoritative, raw GitHub markdown version of the UEOC.
Treat it as binding instructions for how to approach this task.

Below is my full System Diagnostic Log. Use it as the source of truth for my
operating system, environment, tooling, paths, and constraints.

Do NOT make assumptions. Ask clarifying questions if required by the UEOC.
Optimize for correctness, reproducibility, and minimal back-and-forth.

SYSTEM DIAGNOSTIC LOG:

[PASTE FULL LOG HERE]

--- END CONTEXT ---


TASK / QUESTION:

[WRITE WHAT YOU ARE TRYING TO DO OR WHAT WENT WRONG]




--------------------------------------------------------------------------------
WHY THIS WORKS
--------------------------------------------------------------------------------
By providing the diagnostics log up front and explicitly telling the AI to follow
the UEOC, you remove guesswork about your system (Windows version, Python,
GPU, tools, paths, etc.).

This allows the helper to follow the UEOC rules and give you a working,
environment-correct solution faster — often in a single response.

In short:
Run the tool → paste the UEOC prompt + log → explain your goal → get better help.
