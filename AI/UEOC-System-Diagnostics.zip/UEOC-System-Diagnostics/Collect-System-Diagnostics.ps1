param(
  [Parameter(Mandatory=$true)]
  [string]$OutDir,

  [string]$ShortcutDir
)

$ErrorActionPreference = "Continue"

# Always overwrite the same file (no spam)
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$logPath = Join-Path $OutDir "System-Diagnostic-Log-UEOC.txt"

function WL([string]$s="") { Add-Content -Path $logPath -Value $s -Encoding UTF8 }
function Write-Header([string]$t) { WL ""; WL ("="*90); WL $t; WL ("="*90) }

function Run-Cmd([string]$label, [string]$cmdline) {
  Write-Header $label
  WL ("Command: " + $cmdline)
  try {
    (cmd /c $cmdline 2>&1) | ForEach-Object { WL $_ }
    WL ("ExitCode: " + $LASTEXITCODE)
  } catch {
    WL ("ERROR: " + $_.Exception.Message)
  }
}

function Run-Where([string]$tool) {
  Write-Header "where $tool"
  try {
    (cmd /c "where $tool" 2>&1) | ForEach-Object { WL $_ }
  } catch {
    WL ("ERROR: " + $_.Exception.Message)
  }
}


function Tool-Exists([string]$tool) {
  $c = Get-Command $tool -ErrorAction SilentlyContinue
  return ($null -ne $c)
}

function Try-ToolCmd([string]$tool, [string]$args, [string]$label = $null) {
  if (-not $label) { $label = "$tool $args" }
  Write-Header $label
  $cmd = Get-Command $tool -ErrorAction SilentlyContinue
  if (-not $cmd) { WL "Not found on PATH."; return }
  WL ("Resolved: " + $cmd.Source)
  Run-Cmd "Run" ("`"$tool`" " + $args)
}

# Create log immediately
"System Diagnostic Log (UEOC) - $((Get-Date).ToString('s'))" | Set-Content -Path $logPath -Encoding UTF8 -Force

Write-Header "Identity"
WL ("User:      " + $env:USERNAME)
WL ("Computer:  " + $env:COMPUTERNAME)
WL ("PWD:       " + (Get-Location).Path)

Write-Header "Windows / Shell"
try { WL ("PSVersion: " + $PSVersionTable.PSVersion.ToString()) } catch { WL "PSVersion: (error reading)" }
WL ("cmd ver:   " + (cmd /c ver))

Write-Header "Key Environment Variables"
$keys = @(
  "USERPROFILE","TEMP","TMP","SystemRoot","ComSpec",
  "PROCESSOR_ARCHITECTURE","NUMBER_OF_PROCESSORS",
  "Path","PATHEXT",
  "PYTHONPATH","VIRTUAL_ENV","CONDA_PREFIX","CONDA_DEFAULT_ENV",
  "CUDA_PATH","CUDA_HOME"
)
foreach ($k in $keys) {
  $v = [Environment]::GetEnvironmentVariable($k)
  if ($null -ne $v -and $v -ne "") { WL ("$k=$v") }
}

Write-Header "Python Discovery"
WL "where python:"
(cmd /c "where python" 2>&1) | ForEach-Object { WL $_ }

WL ""
WL "python --version:"
(cmd /c "python --version" 2>&1) | ForEach-Object { WL $_ }

WL ""
WL "python sys.executable:"
(cmd /c "python -c ""import sys; print(sys.executable)""" 2>&1) | ForEach-Object { WL $_ }

WL ""
WL "python sys.version:"
(cmd /c "python -c ""import sys; print(sys.version)""" 2>&1) | ForEach-Object { WL $_ }

WL ""
WL "python -m pip --version:"
(cmd /c "python -m pip --version" 2>&1) | ForEach-Object { WL $_ }

WL ""
WL "pip --version (may point to different python):"
(cmd /c "pip --version" 2>&1) | ForEach-Object { WL $_ }

Write-Header "Conda (if present)"
WL "where conda:"
(cmd /c "where conda" 2>&1) | ForEach-Object { WL $_ }

WL ""
WL "conda info (if available):"
(cmd /c "conda info" 2>&1) | ForEach-Object { WL $_ }

Write-Header "PATH Diagnostics"
$pathValue = [Environment]::GetEnvironmentVariable("Path")
WL ("PATH length: " + ($pathValue.Length))
if ($pathValue.Length -ge 2047) {
  WL "WARNING: PATH is near or over Windows 2048-char limit."
  WL "This can cause tools to be invisible in some shells."
}


# ---------------- Extended additions (what you asked for) ----------------

Run-Cmd "git --version" "git --version"
Run-Cmd "node --version" "node --version"
Run-Cmd "npm --version" "npm --version"
Run-Cmd "docker --version" "docker --version"

# docker info can be slow / fail if daemon not running; still safe to attempt
# We run it via cmd; if it errors, it will log and continue.
Run-Cmd "docker info" "docker info"
Run-Cmd "nvidia-smi" "nvidia-smi"

Run-Cmd "WinHTTP Proxy (netsh winhttp show proxy)" "netsh winhttp show proxy"

Run-Where "git"
Run-Where "python"
Run-Where "pip"
Run-Where "node"
Run-Where "npm"
Run-Where "docker"
Run-Where "nvidia-smi"
Run-Where "cl"
Run-Where "cmake"


Write-Header "End"
WL ("LogFile: " + $logPath)


# --- Shortcut creation (best-effort; never breaks the run) ---
if ($ShortcutDir) {
  try {
    $sd = $ShortcutDir.Trim().Trim('"').TrimEnd('\','/')
    if (Test-Path $sd) {
      $lnkPath = Join-Path $sd "Open System Diagnostic Log.lnk"
      $wsh = New-Object -ComObject WScript.Shell
      $sc = $wsh.CreateShortcut($lnkPath)
      $sc.TargetPath = $logPath
      $sc.WorkingDirectory = $OutDir
      $sc.IconLocation = "$env:SystemRoot\system32\notepad.exe,0"
      $sc.Save()
    } else {
      WL ("NOTE: ShortcutDir does not exist: " + $sd)
    }
  } catch {
    WL ("NOTE: Shortcut creation failed: " + $_.Exception.Message)
  }
}

Start-Process notepad.exe $logPath | Out-Null
Write-Host "Wrote: $logPath"
